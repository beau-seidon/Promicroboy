%TF.GenerationSoftware,KiCad,Pcbnew,9.0.3*%
%TF.CreationDate,2025-08-31T22:47:13-05:00*%
%TF.ProjectId,3u_panel,33755f70-616e-4656-9c2e-6b696361645f,v0.2*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3) date 2025-08-31 22:47:13*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,7.400000X4.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X129331752Y-145584751D03*
%TD*%
%TO.C,*%
X129331752Y-23084751D03*
%TD*%
M02*
