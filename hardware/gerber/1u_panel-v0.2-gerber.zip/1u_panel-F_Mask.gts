%TF.GenerationSoftware,KiCad,Pcbnew,9.0.3*%
%TF.CreationDate,2025-09-01T10:24:00-05:00*%
%TF.ProjectId,1u_panel,31755f70-616e-4656-9c2e-6b696361645f,v0.2*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3) date 2025-09-01 10:24:00*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,7.400000X4.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X164041171Y-32259764D03*
%TD*%
%TO.C,*%
X164041171Y-65909764D03*
%TD*%
%TO.C,*%
X67341171Y-65909764D03*
%TD*%
%TO.C,*%
X67341171Y-32259764D03*
%TD*%
M02*
